package register;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;

import junit.framework.TestCase;

public class CashRegisterTest extends TestCase{
	CashRegister ch;
	JSONArray obj;
	
	@Override  
    protected void setUp() throws Exception  
    {   
        super.setUp();  
        ch = new CashRegister();
        obj = new JSONArray();
        obj.add("ITEM000001");
        obj.add("ITEM000001");
        obj.add("ITEM000001");
        obj.add("ITEM000001");
        obj.add("ITEM000001-3");
        obj.add("ITEM000002");
        obj.add("ITEM000003");
        obj.add("ITEM000003");
        obj.add("ITEM000005");
        obj.add("ITEM000007");
        obj.add("ITEM000007-2");
        
        System.out.println("setUp()");  
    } 
	
	/*
	 *  A case should fail since the item is not included in our product list
	 */
	public void testInvalidSetBuy2Give1IDs() {
		List<String> list = new ArrayList<String>();
		list.add("ITEM000001");
		// this is an invalid id
		list.add("ITEM000009");
		ch.setPayFreeIDs(list);
		assertEquals(2, ch.getPayFreeIDs().size());
	}
	
	/*
	 * A case to test set vallid ids to list of buy2Give1
	 */
	public void testValidSetBuy2Give1IDS() {
		List<String> list = new ArrayList<String>();
		list.add("ITEM000001");
		list.add("ITEM000005");
		ch.setPayFreeIDs(list);
		assertEquals(2, ch.getPayFreeIDs().size());
	}
	
	/*
	 * A case to test print results when no any activity
	 */
	public void testNoActivity() {
		System.out.println("Test for no any activity");
		System.out.println("#########################################################");
		
		List<String> list = new ArrayList<String>();
		ch.setPayFreeIDs(list);
		ch.setDiscountIDs(list);
		Map<String, Integer> inputData = ch.mergeInputData(obj);
		ch.processCommodities(ch.getAllCommodities(), inputData);
		
	}
	
	/*
	 * A case to test print results when only pay 2 free 1 activity
	 */
	public void testOnlyPay2Free1Activity() {
		System.out.println("Test for only pay 2 free 1 activity");
		System.out.println("#########################################################");
		
		List<String> list = new ArrayList<String>();
		list.add("ITEM000001");
		list.add("ITEM000007");
		ch.setPayFreeIDs(list);
		ch.setDiscountIDs(new ArrayList<String>());
		
		Map<String, Integer> inputData = ch.mergeInputData(obj);
		ch.processCommodities(ch.getAllCommodities(), inputData);
	}
	
	/*
	 * A case to test Pay 2 Free 1 and Discount 95 activities
	 * NOTE that here these activities work for a commondity which has only 2
	 */
	public void testPay2Free1AndDiscount95Activities2() {
		System.out.println("Test for Pay 2 Free 1 and Discount 95 activities");
		System.out.println("NOTE that here these activities work for a commondity which has only 2");
		System.out.println("#########################################################");
		
		List<String> list = new ArrayList<String>();
		list.add("ITEM000003");
		ch.setPayFreeIDs(list);
		List<String> list2 = new ArrayList<String>();
		list2.add("ITEM000003");
		ch.setDiscountIDs(list2);
		
		Map<String, Integer> inputData = ch.mergeInputData(obj);
		ch.processCommodities(ch.getAllCommodities(), inputData);
	}
	
	/*
	 * A case to test print results when only discount 95 activity
	 */
	public void testOnlyDiscount95Activity() {
		System.out.println("Test for only discount 95 activity");
		System.out.println("#########################################################");
		
		ch.setPayFreeIDs(new ArrayList<String>());
		List<String> list = new ArrayList<String>();
		list.add("ITEM000001");
		list.add("ITEM000007");
		ch.setDiscountIDs(list);
		
		Map<String, Integer> inputData = ch.mergeInputData(obj);
		ch.processCommodities(ch.getAllCommodities(), inputData);
	}
	
	/*
	 * A case to test print results when both activities
	 */
	public void testPay2Free1AndDiscount95Activities() {
		System.out.println("Test for Pay 2 Free 1 and Discount 95 activities");
		System.out.println("#########################################################");
		
		List<String> list = new ArrayList<String>();
		list.add("ITEM000001");
		list.add("ITEM000007");
		ch.setPayFreeIDs(list);
		List<String> list2 = new ArrayList<String>();
		list2.add("ITEM000005");
		ch.setDiscountIDs(list2);
		
		Map<String, Integer> inputData = ch.mergeInputData(obj);
		ch.processCommodities(ch.getAllCommodities(), inputData);
	}
	
	@Override  
    protected void tearDown() throws Exception  
    {  
        super.tearDown();  
        System.out.println("tearDown()");  
    }  
}
