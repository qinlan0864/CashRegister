package register;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;

public class CashRegister {

	private static String commonPath = "data";
	private static String commodityFileName = "commodities.txt";
	private static String activityFileName = "activities.txt";
	private static String inputFileName = "inputs1.json";
	private static String rowSeperater = ",";
	private static String numSeperater = "-";
	private static DecimalFormat df = new DecimalFormat("0.00");
	private static int pay_num = 2;
	private static int free_num = 1;
	private static double discount = 0.95;

	 // ids for all commodities registered
	private List<String> ids = new ArrayList<String>();
	// ids for discount 95 IDs promotion activity
	private List<String> discountIDs = new ArrayList<String>(); 
	// ids for pay 2 free 1 promotion activity
	private List<String> payFreeIDs = new ArrayList<String>(); 
	// actual ids for pay 2 free 1 promotion activity
	private List<String> actualPayFreeCommodities = new ArrayList<String>(); 
	// info for all commodities, which use id as key
	private Map<String, Commodity> allCommodities = null; 

	// total pay money
	private double totalMoney;
	private double totalDiscount;

	public CashRegister() {
		// read information of all commodities
		allCommodities = readCommoditiesInfo();
		// read all promotion activities
		readAcitivitiesInfo();
	}
	
	public static void main(String[] args) {
		CashRegister ch = new CashRegister();
		
		// read input data
		String str = ch.readJsonFile(commonPath + File.separator + inputFileName);
		JSONArray obj = JSONArray.fromObject(str);	

		// process commodities, print result
		ch.processCommodities(ch.getAllCommodities(), ch.mergeInputData(obj));
	}

	public void clear() {
		ids.clear();
		payFreeIDs.clear();
		discountIDs.clear();	
		actualPayFreeCommodities.clear();
		allCommodities.clear();
		totalMoney = 0.0;
		totalDiscount = 0.0;
	}
	
	/*
	 * Print list of all input commodities
	 */
	public void printCommoditiesList(Map<String, Commodity> commodities) {
		System.out.println("***<没钱赚商店>购物清单***");
		for (String id : commodities.keySet()) {
			Commodity pro = commodities.get(id);
			if (pro.getNum() <= 0) continue;
			if (payFreeIDs.contains(id) && (pro.getNum() / (pay_num + free_num) > 0)) {
				printCommondity(pro, false);
			} else if (discountIDs.contains(id)) {
				printCommondity(pro, true);
			} else {
				printCommondity(pro, false);
			}
		}
		printTotalPayFreeAcivity(commodities);
		printTotalNum();
		System.out.println("**********************");
	}
	
	private void printTotalPayFreeAcivity(Map<String, Commodity> commodities) {
		System.out.println("----------------------");
		if (actualPayFreeCommodities.size() > 0) {
			System.out.println("买二赠一商品：");
			for (String id : actualPayFreeCommodities) {
				printPayFreeCommondity(commodities.get(id));
			}
			System.out.println("----------------------");
		}
	}
	
	private void printTotalNum() {
		System.out.println(String.format("总计：%s(元)", df.format(totalMoney)));
		if (totalDiscount > 0) {
			System.out.println(String.format("节省：%s(元)", df.format(totalDiscount)));
		}
	}

	private void printCommondity(Commodity commodity,boolean isDiscount95) {	
		String message = "名称：%s，数量：%s %s，单价：%s(元)，总计：%s(元)";
		message = String.format(message, commodity.getName(), commodity.getNum(), commodity.getUnit(), commodity.getPrice(),
				df.format(commodity.getTotalPrice()));
		if (isDiscount95) {
			String discountMessage = "，节省 %s(元)";
			discountMessage = String.format(discountMessage, df.format(commodity.getNum() * commodity.getPrice() * 0.05));
			message += discountMessage;
		}

		System.out.println(message);
	}

	private void printPayFreeCommondity(Commodity pro) {
		String message = "名称：%s，数量：%s%s";
		message = String.format(message, pro.getName(), pro.getNum() / (free_num + pay_num), pro.getUnit());
		System.out.println(message);
	}

	public void processCommodities(Map<String, Commodity> commodities, Map<String, Integer> inputDatas) {		
		for (String id : inputDatas.keySet()) {
			int num = inputDatas.get(id);
			double totalPrice = 0;
			Commodity commodity = getAllCommodities().get(id);
			commodity.setNum(num);
			if (payFreeIDs.contains(id) && (num / (free_num + pay_num) > 0)) {
				totalPrice = handlePayFreeActivity(commodity, totalPrice, num);
			} else {
				if (discountIDs.contains(id)) {
					totalPrice = handleDiscountActivity(commodity, totalPrice, num);
				} else {
					// no any activity
					totalPrice = num * commodity.getPrice();
				}
			}
			
			commodity.setTotalPrice(totalPrice);
			totalMoney += totalPrice;
		}
		
		printCommoditiesList(commodities);
		clear();
	}
	
	/*
	 *  handle pay free activity
	 */
	private double handlePayFreeActivity(Commodity commodity, double totalPrice, int num) {
		// consider buy 2 give 1 activity first
		actualPayFreeCommodities.add(commodity.getID());
		totalPrice = (num - num  / (free_num + pay_num)) * commodity.getPrice();
		totalDiscount += (num / (free_num + pay_num)) * commodity.getPrice();
		
		return totalPrice;
	}
	
	/*
	 * handle discount activity
	 */
	private double handleDiscountActivity(Commodity pro, double totalPrice, int num) {
		// just discount activity
		totalPrice = num * pro.getPrice() * discount;
		totalDiscount += num * pro.getPrice() * (1 - discount);
		
		return totalPrice;
	}
	
	/*
	 * read information for all commodities from config file
	 */
	public Map<String, Commodity> readCommoditiesInfo() {
		List<String[]> rows = readFiles(commonPath + File.separator + commodityFileName);
		Map<String, Commodity> commdities = new HashMap<String, Commodity>();
		ids.clear();
		for (String[] row : rows) {
			String id = row[0];
			if (!commdities.containsKey(id)) {
				// record unique id
				ids.add(id);
				Commodity pro = new Commodity(id);
				pro.setName(row[1]);
				double price = 0.0;
				try {
					price = Double.parseDouble(row[2]);
				} catch (NumberFormatException ex) {
					// do nothing here
				}
				pro.setPrice(price);
				pro.setUnit(row[3]);
				commdities.put(id, pro);
			}
		}

		return commdities;
	}

	/*
	 * read information for all activities from config file
	 */
	public void readAcitivitiesInfo() {
		List<String[]> rows = readFiles(commonPath + File.separator + activityFileName);
		for (String[] row : rows) {
			String id = row[0];
			if (ids.contains(id)) {
				boolean payFree = row[1].compareTo("1") == 0;
				boolean discount = row[2].compareTo("1") == 0;
				if (payFree && (!payFreeIDs.contains(id))) {
					payFreeIDs.add(id);
				}

				if (discount && (!discountIDs.contains(id))) {
					discountIDs.add(id);
				}
			}
		}
	}

	/*
	 * merge rows of same commodity into 1
	 */
	public Map<String, Integer> mergeInputData(JSONArray obj) {
		Map<String, Integer> newInputs = new HashMap<String, Integer>();
		for(int i = 0; i < obj.size(); i++) {
			String newInput = obj.getString(i);
			if (newInput.contains(numSeperater)) {
				String[] items = newInput.split(numSeperater);
				if (items.length != 2)
					// an invalid row, ignore it
					continue;
				else {
					String id = items[0];
					int num = Integer.parseInt(items[1]);
					if (newInputs.containsKey(id)) {
						Integer oldNum = newInputs.get(id);
						newInputs.put(id, oldNum + num);
					} else {
						newInputs.put(id, num);
					}
				}
			} else {
				if (newInputs.containsKey(newInput)) {
					Integer oldNum = newInputs.get(newInput);
					newInputs.put(newInput, oldNum + 1);
				} else {
					newInputs.put(newInput, 1);
				}
			}
		}

		return newInputs;

	}

	/*
	 * read file from specified path, the file is a table and separator cells by row separator 
	 */
	public List<String[]> readFiles(String path) {
		File file = new File(path);

		List<String[]> results = new ArrayList<String[]>();
		try {
			InputStream is = new FileInputStream(file);
			BufferedReader in = new BufferedReader(new InputStreamReader(is));
			String row = "";
			boolean isTitle = true;
			while ((row = in.readLine()) != null) {
				if (isTitle) {
					isTitle = false;
					continue;
				} else {
					String[] cells = row.split(rowSeperater);
					if (cells.length <= 0 || cells[0].length() <= 0)
						continue;
					else {
						results.add(cells);
					}
				}
			}
		} catch (FileNotFoundException e) {
			return new ArrayList<String[]>();
		} catch (IOException e) {
			return new ArrayList<String[]>();
		}

		return results;
	}
	
	/*
	 * read json file from specified path
	 */
	public String readJsonFile(String path) {
		File file = new File(path);
		StringBuilder sb = new StringBuilder(); 
		try {
			InputStream is = new FileInputStream(file);
			BufferedReader in = new BufferedReader(new InputStreamReader(is));	
			String line = "";
			
			while ((line = in.readLine()) != null) {
				sb.append(line);
			}
		} catch (FileNotFoundException e) {
			return "";
		} catch (IOException e) {
			return "";
		} 
		
		return sb.toString();
	}
	
	protected Map<String, Commodity> getAllCommodities() {
		return allCommodities;
	}

	public List<String> getDiscountIDs() {
		return this.discountIDs;
	}
	
	public void setDiscountIDs(List<String> list) {
		if (this.ids.containsAll(list)) {
			this.discountIDs = list;
		} else {
			System.out.println("Invalid ids found!");
			this.discountIDs.clear();
		}
	}
	
	public List<String> getPayFreeIDs() {
		return this.payFreeIDs;
	}

	public void setPayFreeIDs(List<String> list) {
		if (this.ids.containsAll(list)) {
			this.payFreeIDs = list;
		} else {
			System.out.println("Invalid ids found!");
			this.payFreeIDs.clear();
		}
	}
	
	/*
	 * we could config our promotion activity, such as pay 3 free 2, here config pay number
	 */
	public void setPayNum(int num) {
		this.pay_num = num;
	}
	
	/*
	 * config free number of commondity in promotion activity
	 */
	public void setFreeNum(int num) {
		this.free_num = num;
	}
	
	/*
	 * config discount percent in promotion activity
	 */
	public void setDiscountPercent(double percent) {
		this.discount = percent;
	}
}

